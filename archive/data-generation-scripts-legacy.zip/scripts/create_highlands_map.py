#!/usr/bin/env python3
"""
Create a 'Highlands Without Settlements' map showing all areas of Northern Ireland
with an elevation of 243m or higher (above max settlement elevation).
"""

import geopandas as gpd
import pandas as pd
import numpy as np
from shapely.geometry import Point, box
from shapely.ops import unary_union
import warnings
warnings.filterwarnings('ignore')

ELEVATION_THRESHOLD = 243  # meters

print(f"Creating Highlands Without Settlements map (>= {ELEVATION_THRESHOLD}m)")
print("=" * 60)

print("\n1. Loading OSNI 50m DTM data...")
dtm = pd.read_csv('data/maps/physical/osni_50m_dtm/OSNI_OpenData_50m_DTM.csv')
print(f"   Total points: {len(dtm):,}")

# Filter to high elevation points
high_points = dtm[dtm['Z'] >= ELEVATION_THRESHOLD].copy()
print(f"   Points >= {ELEVATION_THRESHOLD}m: {len(high_points):,}")

if len(high_points) == 0:
    print("ERROR: No points found above threshold!")
    exit(1)

print(f"   Elevation range: {high_points['Z'].min():.1f}m to {high_points['Z'].max():.1f}m")

print("\n2. Creating 50m grid cells for each point...")
cells = []
for _, row in high_points.iterrows():
    x, y = row['X'], row['Y']
    # Create a 50m x 50m cell centered on the point
    cell = box(x - 25, y - 25, x + 25, y + 25)
    cells.append(cell)

print(f"   Created {len(cells):,} cells")

print("\n3. Merging overlapping cells (this may take a moment)...")
# Merge all cells into unified polygons
merged = unary_union(cells)
print(f"   Merged geometry type: {merged.geom_type}")

# Convert to list of polygons
if merged.geom_type == 'MultiPolygon':
    polygons = list(merged.geoms)
elif merged.geom_type == 'Polygon':
    polygons = [merged]
else:
    polygons = [merged]

print(f"   Number of distinct highland areas: {len(polygons)}")

# Create output GeoDataFrame with properties
highlands_gdf = gpd.GeoDataFrame({
    'Name': [f'Highland Area {i+1}' for i in range(len(polygons))],
    'Threshold_m': [ELEVATION_THRESHOLD] * len(polygons),
    'Description': ['Area above maximum settlement elevation'] * len(polygons)
}, geometry=polygons, crs='EPSG:29903')

# Calculate area for each polygon
highlands_gdf['Area_km2'] = highlands_gdf.geometry.area / 1e6

# Sort by area (largest first)
highlands_gdf = highlands_gdf.sort_values('Area_km2', ascending=False).reset_index(drop=True)
highlands_gdf['Name'] = [f'Highland Area {i+1}' for i in range(len(highlands_gdf))]

print(f"   Total highland area: {highlands_gdf['Area_km2'].sum():.1f} km²")
print(f"   Largest area: {highlands_gdf['Area_km2'].iloc[0]:.1f} km²")

print("\n4. Reprojecting to WGS84...")
highlands_wgs84 = highlands_gdf.to_crs('EPSG:4326')

print("\n5. Saving to FlatGeoBuf...")
output_path = 'data/maps/physical/Highlands_Without_Settlements.fgb'
highlands_wgs84.to_file(output_path, driver='FlatGeobuf')
print(f"   Saved to: {output_path}")

# Summary stats
print("\n" + "=" * 60)
print("SUMMARY")
print("=" * 60)
print(f"Elevation threshold: {ELEVATION_THRESHOLD}m")
print(f"Total highland areas: {len(highlands_gdf)}")
print(f"Total area: {highlands_gdf['Area_km2'].sum():.1f} km²")
print(f"Top 5 highland areas by size:")
for i, row in highlands_gdf.head(5).iterrows():
    print(f"  {row['Name']}: {row['Area_km2']:.1f} km²")

print(f"\nOutput file: {output_path}")
print("Done!")
