"""
Download SRTM GL1 (30m) DEM covering Ireland from OpenTopography API.
Output: data/temp/ireland_dem/ireland_dem_30m.tif
"""
import os
import urllib.request
import ssl

# Create output directory
os.makedirs('data/temp/ireland_dem', exist_ok=True)

# Ireland bounding box (with buffer for edge effects)
SOUTH = 51.0
NORTH = 55.6
WEST = -10.8
EAST = -5.3

# OpenTopography public demo API
url = (
    f"https://portal.opentopography.org/API/globaldem?"
    f"demtype=SRTMGL1&south={SOUTH}&north={NORTH}&west={WEST}&east={EAST}"
    f"&outputFormat=GTiff&API_Key=demoapikeyot2022"
)

output_file = 'data/temp/ireland_dem/ireland_dem_30m.tif'

print(f"Downloading SRTM GL1 DEM for Ireland...")
print(f"Bounds: {SOUTH}°N to {NORTH}°N, {WEST}°W to {EAST}°W")
print(f"Output: {output_file}")

# Download with progress
context = ssl._create_unverified_context()
try:
    urllib.request.urlretrieve(url, output_file)
    size_mb = os.path.getsize(output_file) / (1024 * 1024)
    print(f"Download complete: {size_mb:.1f} MB")
except Exception as e:
    print(f"Error downloading: {e}")
    raise
