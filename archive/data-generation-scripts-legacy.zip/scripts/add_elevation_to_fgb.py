#!/usr/bin/env python3
"""
Add PRECISE min/max elevation to all FGB files using vectorized spatial join.
Uses geopandas sjoin for fast point-in-polygon matching.
"""
import geopandas as gpd
import pandas as pd
import numpy as np
from glob import glob
import time
import os
import warnings
warnings.filterwarnings('ignore')

print("=== Adding PRECISE Elevation Data (Vectorized) ===\n")

# Load DTM as points GeoDataFrame (once, reuse for all files)
start = time.time()
dtm = pd.read_csv('data/maps/physical/osni_50m_dtm/OSNI_OpenData_50m_DTM.csv')
dtm_gdf = gpd.GeoDataFrame(
    dtm,
    geometry=gpd.points_from_xy(dtm.X, dtm.Y),
    crs='EPSG:29903'
)
print(f"Loaded DTM: {len(dtm):,} points in {time.time()-start:.1f}s")

# Build spatial index on DTM points
dtm_gdf.sindex

# Get all FGB files
fgb_files = glob('data/**/*.fgb', recursive=True)
print(f"Found {len(fgb_files)} FGB files\n")

# Process each file
start_total = time.time()
total_features = 0
files_updated = 0

for i, fpath in enumerate(fgb_files):
    fname = os.path.basename(fpath)
    try:
        start_file = time.time()
        
        # Read FGB
        gdf = gpd.read_file(fpath)
        original_crs = gdf.crs
        
        # Convert to Irish Grid for elevation lookup
        try:
            gdf_irish = gdf.to_crs('EPSG:29903')
        except:
            print(f"[{i+1}/{len(fgb_files)}] {fname}: CRS error, skipping")
            continue
        
        # Spatial join: find DTM points within each polygon
        try:
            joined = gpd.sjoin(dtm_gdf, gdf_irish, how='inner', predicate='within')
        except Exception as e:
            print(f"[{i+1}/{len(fgb_files)}] {fname}: sjoin error, skipping")
            continue
        
        if len(joined) == 0:
            # No DTM points in any polygon - set all to None
            gdf['minElev_m'] = None
            gdf['maxElev_m'] = None
            gdf['minElev_ft'] = None
            gdf['maxElev_ft'] = None
        else:
            # Group by polygon index and calculate min/max
            stats = joined.groupby('index_right')['Z'].agg(['min', 'max'])
            
            # Map back to original dataframe
            gdf['minElev_m'] = gdf.index.map(lambda idx: round(stats.loc[idx, 'min'], 1) if idx in stats.index else None)
            gdf['maxElev_m'] = gdf.index.map(lambda idx: round(stats.loc[idx, 'max'], 1) if idx in stats.index else None)
            gdf['minElev_ft'] = gdf['minElev_m'].apply(lambda x: round(x * 3.28084) if pd.notna(x) else None)
            gdf['maxElev_ft'] = gdf['maxElev_m'].apply(lambda x: round(x * 3.28084) if pd.notna(x) else None)
        
        # Save back to FGB
        gdf.to_file(fpath, driver='FlatGeobuf')
        
        elapsed_file = time.time() - start_file
        total_features += len(gdf)
        files_updated += 1
        
        print(f"[{i+1}/{len(fgb_files)}] {fname}: {len(gdf)} features in {elapsed_file:.1f}s")
        
    except Exception as e:
        print(f"[{i+1}/{len(fgb_files)}] {fname}: Error - {str(e)[:60]}")

elapsed_total = time.time() - start_total
print(f"\n=== Complete ===")
print(f"Files updated: {files_updated}")
print(f"Total features: {total_features:,}")
print(f"Total time: {elapsed_total:.0f}s ({elapsed_total/60:.1f} min)")
