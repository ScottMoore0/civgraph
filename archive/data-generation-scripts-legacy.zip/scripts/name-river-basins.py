"""
Assign river/estuary names to HydroBASINS polygons for Ireland.
Uses estuary coordinates to match polygons to known river systems.
"""

import geopandas as gpd
from shapely.geometry import Point, box
import sys

# Ireland bounding box
IRELAND_BBOX = [-10.7, 51.3, -5.3, 55.5]

# Major Irish river estuaries with approximate outlet coordinates (lon, lat)
# These are the points where rivers meet the sea
ESTUARIES = {
    # Atlantic / West Coast
    "Shannon": (-9.5, 52.6),      # Shannon Estuary
    "Corrib": (-9.05, 53.27),     # Galway Bay
    "Moy": (-9.18, 54.2),         # Killala Bay
    "Erne": (-8.2, 54.5),         # Donegal Bay
    "Swilly": (-7.55, 55.15),     # Lough Swilly
    "Garavogue": (-8.5, 54.28),   # Sligo Bay
    
    # North Coast
    "Foyle": (-7.25, 55.05),      # Lough Foyle
    "Bann": (-6.68, 55.17),       # Bann Estuary (Coleraine)
    
    # Irish Sea / East Coast  
    "Lagan": (-5.85, 54.62),      # Belfast Lough
    "Newry": (-6.1, 54.1),        # Carlingford Lough
    "Boyne": (-6.25, 53.72),      # Boyne Estuary (Drogheda)
    "Liffey": (-6.15, 53.35),     # Dublin Bay
    "Slaney": (-6.45, 52.33),     # Wexford Harbour
    "Dee/Fane/Glyde": (-6.35, 53.95),  # Dundalk Bay
    
    # Celtic Sea / South Coast
    "Barrow/Nore/Suir": (-6.95, 52.15),  # Waterford Harbour (Three Sisters)
    "Blackwater": (-7.85, 51.95),  # Youghal
    "Lee": (-8.28, 51.85),         # Cork Harbour
    "Bandon": (-8.52, 51.7),       # Kinsale
}

def get_nearest_estuary(geometry, estuaries):
    """Find the nearest estuary to a polygon's centroid."""
    centroid = geometry.centroid
    min_dist = float('inf')
    nearest = "Unknown"
    
    for name, (lon, lat) in estuaries.items():
        estuary_point = Point(lon, lat)
        dist = centroid.distance(estuary_point)
        if dist < min_dist:
            min_dist = dist
            nearest = name
    
    return nearest

def main():
    # Use level 7 for good detail but not too fragmented
    shp_path = "data/temp/hybas_eu/hybas_eu_lev07_v1c.shp"
    output_path = "data/maps/physical/Named_River_Basins.fgb"
    
    print(f"Loading {shp_path}...")
    gdf = gpd.read_file(shp_path)
    
    # Filter to Ireland
    minx, miny, maxx, maxy = IRELAND_BBOX
    ireland_box = box(minx, miny, maxx, maxy)
    ireland_mask = gdf.geometry.intersects(ireland_box)
    ireland_gdf = gdf[ireland_mask].copy()
    print(f"Features in Ireland: {len(ireland_gdf)}")
    
    # Assign river names based on nearest estuary
    print("Assigning river names...")
    ireland_gdf['river_name'] = ireland_gdf.geometry.apply(
        lambda geom: get_nearest_estuary(geom, ESTUARIES)
    )
    
    # Create display name
    ireland_gdf['name'] = ireland_gdf['river_name'] + " Basin"
    
    # Count basins per river
    print("\nBasins per river system:")
    counts = ireland_gdf['river_name'].value_counts()
    for river, count in counts.items():
        print(f"  {river}: {count} sub-basins")
    
    # Dissolve polygons by river name to get one polygon per major system
    print("\nDissolving to create one polygon per river system...")
    dissolved = ireland_gdf.dissolve(by='river_name', as_index=False)
    dissolved['name'] = dissolved['river_name'] + " Basin"
    
    print(f"Created {len(dissolved)} major river basin polygons")
    
    # Save
    print(f"\nSaving to {output_path}...")
    dissolved.to_file(output_path, driver="FlatGeobuf")
    print("Done!")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
